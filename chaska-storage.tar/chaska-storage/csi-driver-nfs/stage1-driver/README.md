# NFS CSI Driver
Installs the NFS CSI driver to expose RWO pvc's as RWX pvc's (see bases/csi-driver-nfs-pvc for details on poc)
