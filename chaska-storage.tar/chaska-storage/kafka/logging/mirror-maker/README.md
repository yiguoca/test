# [Strimzi - MirrorMaker2](https://strimzi.io/blog/2020/03/30/introducing-mirrormaker2/)

The Strimzi MirrorMaker2 operator handles running MirrorMaker2 in a kubernetes cluster. It works in conjunction with the Strimzi operator and kafka deployments. 