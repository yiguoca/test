# chaska-storage rabbitmq
The chaska-storage `fcaus-f-storage` cluster has a rabbitmq instance setup using rabbitmq-cluster-operator and rabbitmq-topology-operator. 

![rabbitmq diagram](rabbitmq.diagrams.net.png)
