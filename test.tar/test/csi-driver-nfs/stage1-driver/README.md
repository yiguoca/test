# NFS CSI Driver
Installs the NFS CSI driver to expose RWO pvc's as RWX pvc's (see `../csi-driver-nfs-test` for sample deployment)
