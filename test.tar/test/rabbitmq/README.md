# teif rabbitmq
The teif cluster has a rabbitmq instance setup using rabbitmq-cluster-operator and rabbitmq-topology-operator. 

![rabbitmq diagram](rabbitmq.diagrams.net.png)
