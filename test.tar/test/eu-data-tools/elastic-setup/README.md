To be executed after [elastic](../elastic/) has been deployed; this stage defines
all the various post deployment setups such as data views/streams and redundancy
via the elastic/kibana rest api.
