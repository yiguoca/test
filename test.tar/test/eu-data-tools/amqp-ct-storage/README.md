# fcaus-te `eu-data-tools` rabbitmq

The rabbitmq service in `fcaus-te` cluster is a service and endpoints pair pointing at the rabbitmq node-port service running in `fcaus-ct-storage` cluster namespace `eu-data-tools`  
