Contains all the ssl [generators] to be shared across the test cluster for
namespaces that need them. The intention is to help manage certificate update
rollouts to a single location for a cluster.

| Secret Id | Cert |
|:----------|:-----|
| [`3149`]  | `*.fcaus-te.autodata.tech` |


[generators]: ./generators/
[`3149`]: https://autodata.secretservercloud.com/app/#/secrets/3149/general
